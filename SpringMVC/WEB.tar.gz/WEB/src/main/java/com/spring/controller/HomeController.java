package com.spring.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	@RequestMapping(value="/showMessage",method = RequestMethod.GET)
	public String getIndex(Model model,HttpServletRequest request){
		model.addAttribute("MESSAGE","HELLO MODEL BOLO JAI MATA DI");
		model.addAttribute("AUTH",request.getAuthType());
		return "showMessage";
	}
	
	@RequestMapping(value="/login",method = RequestMethod.GET)
	public String login(Model model){
		System.out.println("LOGIn");
		return "login";
	}
	
	
}
