package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.beans.StudentRegistration;

@Controller
public class StudentHomeController {

	@RequestMapping(value = "/studentStart", method = RequestMethod.GET)
	public String student(Model model) {
		model.addAttribute("Student", new StudentRegistration());
		return "studentRegForm";

	}

	@RequestMapping(value = "/studentRegForm", method = RequestMethod.POST)
	public String studentSubmit(@ModelAttribute("Student") StudentRegistration studentReg, ModelMap model) {
		model.addAttribute("Data", studentReg);
		return "registrationSuccess";
	}

}
