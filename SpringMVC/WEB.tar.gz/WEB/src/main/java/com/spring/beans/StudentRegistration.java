package com.spring.beans;

import java.util.Arrays;

public class StudentRegistration {
	private int id;
	private String firstName;
	private String lastName;
	private int age;
	private String[] city;
	private String[] course;
	private int marks;
	private String gender;
	private String email;
	private int mobile;
	private int fee;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String []getCity() {
		return city;
	}
	public void setCity(String[] city) {
		this.city = city;
	}
	public String[] getCourse() {
		return course;
	}
	public void setCourse(String[] course) {
		this.course = course;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public int getFee() {
		return fee;
	}
	public void setFee(int fee) {
		this.fee = fee;
	}
	@Override
	public String toString() {
		return "StudentRegistration [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", city=" + Arrays.toString(city) + ", course=" + Arrays.toString(course) + ", marks=" + marks
				+ ", gender=" + gender + ", email=" + email + ", mobile=" + mobile + ", fee=" + fee + "]";
	}
	

	
}
