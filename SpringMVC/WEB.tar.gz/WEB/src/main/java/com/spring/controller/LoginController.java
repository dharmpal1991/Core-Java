package com.spring.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/registration")
public class LoginController {
	
	@RequestMapping(params = "form", method = RequestMethod.GET)
	public String createForm(Model model, HttpServletRequest request) {
		model.addAttribute("message", "SuccessfulRegister");
		return "Registration";
	}
	
	@RequestMapping(method = RequestMethod.POST, produces = "text/html")
	public String registerationUser(Model model,HttpServletRequest request){
		System.out.println();
		String uname = request.getParameter("uname");
		System.out.println(uname);
		String lname = request.getParameter("lname");
		System.out.println(lname);
		String email = request.getParameter("email");
		System.out.println(email);
		model.addAttribute("form", "registrationFromSuccessfull");
		model.addAttribute("data", model);
		return "formRegister";
	}

}
